package scripts;

import helpers.DriverFactory;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.WebDriver;
import pages.LoginPage;
import listeners.TestListener;

@ExtendWith(TestListener.class)
public class LoginTest {
    WebDriver driver;

    @BeforeEach
    public void setup() {
        driver = DriverFactory.initDriver();
    }

    @Test
    public void testValidLogin() {
        driver.get("https://olms.yoursite.com");
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("admin", "admin123");
        Assertions.assertTrue(driver.getCurrentUrl().contains("dashboard"));
    }

    @AfterEach
    public void tearDown() {
        driver.quit();
    }
}